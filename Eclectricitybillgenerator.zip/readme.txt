How to run?
1. Import sql file to phpMyAdmin
2. Copy and Paste electricity bill generator folder into htdocs folder of Xampp.

Admin Login
username: Admin
Password: 123

if  Admin table i.e aregister table is empty Admin can register

Admin Roles:
1. Generate Bill
2. Update cost per unit
3. View Feedback

User Roles:
1. View Bill
2. Make Payment
3. Give Feedback
