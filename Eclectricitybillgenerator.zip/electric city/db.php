<?php

@$con=mysqli_connect("localhost", "root" ,"" ,"task3");

if(mysqli_connect_errno()){

  echo "Field to connect to Mysql:" .mysqli_connect_error();

}


?>
