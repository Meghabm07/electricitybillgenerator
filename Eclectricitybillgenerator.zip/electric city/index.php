   <?php
            include("db.php");
            if(isset($_POST['submit']))
            {
              @$contactname=$_POST['contactname'];
              @$contactemail=$_POST['contactemail'];
              @$contactsubject=$_POST['contactsubject'];
              @$contactmessage=$_POST['contactmessage'];
              if(!empty($contactname)&&!empty($contactemail)&&!empty($contactsubject))
              {
                @$query="INSERT into contactus values('$contactname','$contactemail','$contactsubject','$contactmessage')";
                @$query_pro=mysqli_query($con,$query);
                if($query_pro)
                {
                   echo "<script>alert('Thanku! Form Submited Done!!')</script>";
                   echo  "<script>window.open('index.php','_self')</script>";
                }
                else{
                  echo "<script>alert('Form Not Submited Done!!')</script>";
                }
              }
              else
              {
               echo "<script>alert('All field are Required!')</script>";
               echo  "<script>window.open('index.php','_self')</script>";
              }
            }
   ?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>Electricity</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="css/base.css">  
   <link rel="stylesheet" href="css/main.css">
   <link rel="stylesheet" href="css/vendor.css">     

   <!-- script
   ================================================== -->   
	<script src="js/modernizr.js"></script>
	<script src="js/pace.min.js"></script>

   <!-- favicons
	================================================== -->
	<link rel="icon" type="image/png" href="favicon.png">

</head>

<body id="top">

	<!-- header 
   ================================================== -->
   <header>   	
   	<div class="row">

   		<div class="top-bar">
   			<a class="menu-toggle" href="#"><span>Menu</span></a>

	   		<div class="logo">
		         <a href="index.php"><img src="images/logo.gif" height="20px" width="50px" style="margin-left: -20px;margin-top: -7px;"></a>
		      </div>		      
  	<nav id="main-nav-wrap">
					<ul class="main-navigation">
						<li><a href="index.php" title="">Home</a></li>
						<li><a class="smoothscroll"  href="#about" title="">About</a></li>
						<li><a href="login.php" title="">Login</a></li>
						<li><a href="register.php" title="">Register</a></li>
						<li><a class="smoothscroll"  href="#services" title="">Services</a></li>					
						<li><a href="contact.php" title="">Contact</a></li>		
					</ul>
				</nav>    		
   		</div> <!-- /top-bar --> 
   		
   	</div> <!-- /row --> 		
   </header> <!-- /header -->

	<!-- intro section
   ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active" style="padding-top: 80px;">
        <img src="slide1.jpg" alt="Los Angeles" style="width:100%;">
         	<div class="intro-content">
   		<div class="row">

   			<div class="col-twelve">

	   			<h5>We’re the Current Specialist!</h5>
	   			<h1> keeping you wired</h1>

	   			<!-- <p class="intro-position">
	   				<span>Front-end Developer</span>
	   				<span>UI/UX Designer</span> 
	   			</p>
 -->
	   			<a class="button stroke smoothscroll" href="#about" title="">Know More About Us</a>

	   		</div>  
   			
   		</div>   		 		
   	</div> <!-- /intro-content --> 
       </div>

      <div class="item" style="padding-top: 80px;">
        <img src="1.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      <div class="item" style="padding-top: 80px;">
        <img src="2.jpg" alt="New york" style="width:100%;">
      </div>
  </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

   <!-- about section
   ================================================== -->
   <section id="about">  

   	<div class="row section-intro">
   		<div class="col-twelve">

   			<h1>About Us</h1>
   			<center>
   				<p align="justify">We are locally owned and operated which makes our services causal as they are done by friendly and helpful technicians.</p>
   			</center>
   		</div>   		
   	</div> <!-- /section-intro -->

   	<div class="row about-content">

   		<div class="col-six tab-full">

   			 <div style="position:relative;height:0;padding-bottom:56.19%">
               	<iframe src="https://www.youtube.com/embed/QF5aTbfI-ko?ecver=2" style="position:absolute;width:100%;height:200%;left:0" width="641" height="360" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>
               	</iframe>
               </div>
        </div>

   		<div class="col-six tab-full">

             <p>All of our services are backed by our 100% satisfaction guarantee. Our electricians can install anything from new security lighting for your outdoors to a whole home generator that will keep your appliances working during a power outage. Our installation services are always done promptly and safely.</p>

				<ul>
				   <li>
				     Full-service electrical layout, design
				   </li>
				   <li>
				   	Wiring and installation/upgrades
				   </li>
				   <li>
				   	Emergency power solutions (generators)
				   </li>
				   <li>
				   	Virtually any electrical needs you have – just ask!
				   </li>
				</ul> <!-- /skill-bars -->		

   		</div>

   	</div>

   	<div class="row button-section">
   		<div class="col-twelve">
   			<a href="#contact" title="Hire Me" class="button stroke smoothscroll">Know More</a>
   			<a href="#" title="Download CV" class="button button-primary">Home</a>
   		</div>   		
   	</div>

   </section> <!-- /process-->    

	<!-- services Section
   ================================================== -->
	<section id="services">

		<div class="overlay"></div>

		<div class="row section-intro">
   		<div class="col-twelve">

   			<h1>Our Services</h1>
   			<h5>Call us 1 (800) 765-43-21</h5>

   			<p class="lead">Never hesitate when it comes to potential electrical problems. Electrical issues can quickly develop into major catastrophes.</p>

   		</div>   		
   	</div> <!-- /section-intro -->

   	<div class="row services-content">

   		<div id="owl-slider" class="owl-carousel services-list">

	      	<div class="service">	

	      		<span class="icon"><i class="glyphicon glyphicon-lamp"></i></span>            

	            <div class="service-content">	

	            	 <h3>Electrical</h3>

		            <p class="desc">Wiring, Remodels and Additions, Heat detectors
	         		</p>
	         		
	         	</div> 	         	 

				</div> <!-- /service -->

				<div class="service">	

					<span class="icon"><i class="glyphicon glyphicon-fire"></i></span>                          

	            <div class="service-content">	

	            	<h3>Heating</h3>  

		            <p class="desc">Trust our professionals to listen to your needs and problems
	         		</p>

	            </div>	                          

			   </div> <!-- /service -->

			   <div class="service">

			   	<span class="icon"><i class="glyphicon glyphicon-wrench"></i></span>		            

	            <div class="service-content">

	            	<h3>Trouble Shooting</h3>

		            <p class="desc">We think before we start working to save you money

	            </div> 	            	               

			   </div> <!-- /service -->

				<div class="service">

					<span class="icon"><i class="glyphicon glyphicon-modal-window"></i></span>	              

	            <div class="service-content">

	            	<h3>Panels Changes</h3>

		            <p class="desc">Prices that meet your needs and budget
	         		</p> 
	         		
	            </div>                

				</div> <!-- /service -->

			   <div class="service">

			   	<span class="icon"><i class="glyphicon glyphicon-camera"></i></span>	            

	            <div class="service-content">

	            	<h3>Security Systems</h3>

		            <p class="desc">You can view events over a monitor in our home
	        			</p> 

	            </div>	               

			   </div> <!-- /service -->

			   <div class="service">

			   	<span class="icon"><i class="icon-chat"></i></span>	   	           

	            <div class="service-content">

	            	 <h3>Consultant</h3>

		            <p class="desc">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.
	        			</p> 
	        			
	            </div>	               

			   </div> <!-- /service -->

	      </div> <!-- /services-list -->
   		
   	</div> <!-- /services-content -->
		
	</section> <!-- /services -->	


	<!-- stats Section
   ================================================== -->
	<section id="stats" class="count-up">

		<div class="row">
			<div class="col-twelve">
               <center>
				<div class="block-1-6 block-s-1-3 block-tab-1-2 block-mob-full stats-list">

					<div class="bgrid stat">

					</div> <!-- /stat -->					

					<div class="bgrid stat">

						<div class="icon-part">
							<i class="icon-users"></i>
						</div>

						<h3 class="stat-count">
							900
						</h3>

						<h5 class="stat-title">
							Happy Clients
						</h5>

					</div> <!-- /stat -->

					<div class="bgrid stat">

						<div class="icon-part">
							<i class="icon-badge"></i>
						</div>

						<h3 class="stat-count">
							200
						</h3>

						<h5 class="stat-title">
							Awards Received
						</h5>

					</div> <!-- /stat -->									

					<div class="bgrid stat">

						<div class="icon-part">
							<i class="icon-light-bulb"></i>
						</div>

						<h3 class="stat-count">
							120
						</h3>

						<h5 class="stat-title">
							Crazy Ideas
						</h5>

					</div> <!-- /stat -->
                    <div class="bgrid stat">

						<div class="icon-part">
							<i class="icon-pencil-ruler"></i>
						</div>

						<h3 class="stat-count">
							1500
						</h3>

						<h5 class="stat-title">
							Projects Completed
						</h5>

					</div> <!-- /stat -->	
                   </center>
				</div> <!-- /stats-list -->

			</div> <!-- /twelve -->
		</div> <!-- /row -->

	</section> <!-- /stats -->

	
   <!-- contact
   ================================================== -->
	<section id="contact">

		<div class="row section-intro">
   		<div class="col-twelve">

   			<h5>Contact Us</h5>
   			<h1>We Would Love To Hear From You.</h1>

   			<p class="lead"></p>

   		</div> 
   	</div> <!-- /section-intro -->

   	<div class="row contact-form">

   		<div class="col-twelve">

            <!-- form -->
            <form method="post" action="">
      			<fieldset>

                  <div class="form-field">
 						   <input name="contactname" type="text"  placeholder="Name" value="" minlength="2" required="">
                  </div>
                  <div class="form-field">
	      			   <input name="contactemail" type="email" placeholder="Email" value="" required="">
	               </div>
                  <div class="form-field">
	     				   <input name="contactsubject" type="text" placeholder="Subject" value="">
	               </div>                       
                  <div class="form-field">
	                 	<textarea name="contactmessage" name="" placeholder="message" rows="10" cols="50" required=""></textarea>
	               </div>                      
                 <div class="form-field">
                     <button class="submitform" name="submit">Submit</button>
                     <div id="submit-loader">
                        <div class="text-loader">Sending...</div>                             
       				      <div class="s-loader">
								  	<div class="bounce1"></div>
								  	<div class="bounce2"></div>
								  	<div class="bounce3"></div>
								</div>
							</div>
                  </div>
            </form> <!-- Form End -->
   <!-- contact-warning -->
          <!--   <div id="message-warning">            	
            </div>   -->          
            <!-- contact-success -->
      		<div id="message-success">
               <i class="fa fa-check"></i>Your message was sent, thank you!<br>
      		</div>

         </div> <!-- /col-twelve -->
   		
   	</div> <!-- /contact-form -->

   	<div class="row contact-info">

   		<div class="col-four tab-full">

   			<div class="icon">
   				<i class="icon-pin"></i>
   			</div>

   			<h5>Where to find Us</h5>

   			<p>
            #369, 2nd Main Road, Jnanabharathi,<br>
            Mariyappanapalya Main Rd, <br>
            Jnana Jyothi Nagar, Gnana Bharathi,<br>
            Bengaluru, Karnataka 560056

            </p>

   		</div>


   		<div class="col-four tab-full">

   			<div class="icon">
   				<i class="icon-phone"></i>
   			</div>

   			<h5>Call Us At</h5>

   			<p>Phone: (+91) 79790 99710<br>
			   	Mobile: (+91) 79790 99710<br>
			     	Fax: (+91) 79790 99710
			   </p>

   		</div>
   		<div class="col-four tab-full">

   			<div class="icon">
   				<i class="icon-mail"></i>
   			</div>

   			<h5>Email Us At</h5>

   			<p>info@kreativedigtalsolution.com<br>
			   	Career@kreativedigtalsolution.com			     
			   </p>

   		</div>
   		
   	</div> <!-- /contact-info -->
		
	</section> <!-- /contact -->


   <!-- footer
   ================================================== -->

   <footer>
     	<div class="row">

     		<div class="col-six tab-full pull-right social">

     			<ul class="footer-social">        
			      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
			      <li><a href="#"><i class="fa fa-behance"></i></a></li>
			      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
			      <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
			      <li><a href="#"><i class="fa fa-instagram"></i></a></li>
			   </ul> 
	      		
	      </div>

      	<div class="col-six tab-full">
	      	<div class="copyright">
		        	<span>© Copyright Kreative Digital Solution 2018.</span> 	
		         </div>		                  
	      	</div>

	      	<div id="go-top">
		         <a class="smoothscroll" title="Back to Top" href="#top"><i class="fa fa-long-arrow-up"></i></a>
		      </div>

      	</div> <!-- /row -->     	
   </footer>  

   <div id="preloader"> 
    	<div id="loader"></div>
   </div> 

   <!-- Java Script
   ================================================== --> 
   <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>